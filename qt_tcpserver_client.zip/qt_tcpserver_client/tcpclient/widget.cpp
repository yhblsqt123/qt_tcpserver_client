#include "widget.h"
#include "ui_widget.h"
#include <QHostAddress>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //创建socket
    socket = new QTcpSocket(this);

    ui->lineEdit_2->setText( "192.168.15.9");//设置IP 初始值
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);// 密文显示的IP
    ui->lineEdit_3->setText("9999");//设置 端口号的初始值
    // 信号与槽的连接
    //connect(socket,&QTcpSocket::connected,this,&Widget::connectedSlot);//一旦连接建立成功，进入到槽函数去处理
    //connect(socket,&QTcpSocket::disconnected,this,&Widget::disconnectedSlot);//一旦断开连接进入到槽函数处理
    connect(socket,&QTcpSocket::readyRead,this,&Widget::readDataSlot);//一旦有数据可以读，进入槽函数处理
}

Widget::~Widget()
{
    delete ui;
}

//发送消息
void Widget::on_pushButton_clicked()
{
    QString senMsg = ui->lineEdit->text(); //获取要发送的字符串
    if(!senMsg.isEmpty())
    {
       QByteArray arr;
       arr.append(senMsg);
       ui->textBrowser->append(senMsg);//在文本框中也显示发送的内容
       socket->write(arr);//把消息写道socket缓冲区
       ui->lineEdit->clear();
    }
}


//建立和服务器连接
void Widget::on_connectBtn_clicked()
{

    //连接服务器
    socket->connectToHost(QHostAddress(ui->lineEdit_2->text()),ui->lineEdit_3->text().toInt());
}

//一旦连接成功按钮不可用
void Widget::connectedSlot()
{
    ui->connectBtn->setEnabled(false);//连接按钮只能点击一次
}
//一旦断开连接按钮可用
void Widget::disconnectedSlot()
{
    ui->connectBtn->setEnabled(true);//连接按钮只能点击一次
}

//读数据
void Widget::readDataSlot()
{
    QByteArray recvMsg = socket->readAll();//一次性把socket中的内容全部读完
    ui->textBrowser->append(QString(recvMsg));//把字节数组强转字符串
}



//是否明文显示IP
void Widget::on_checkBox_clicked(bool checked)
{
    if(true == checked)
    {
        ui->lineEdit_2->setEchoMode(QLineEdit::Normal);//明文
    }
    else
        ui->lineEdit_2->setEchoMode(QLineEdit::Password);


}

