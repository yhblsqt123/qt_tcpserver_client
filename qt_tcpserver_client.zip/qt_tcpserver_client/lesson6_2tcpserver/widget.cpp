#include "widget.h"
#include "ui_widget.h"
#include <QString>
#include <QByteArray>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    lisSocket = new QTcpServer(this);//创建一个服务端对象进行监听
    connSocket = NULL;

    //绑定并创建监听队列
    lisSocket->listen(QHostAddress::AnyIPv4,9999);

    //连接信号与槽,一旦socket建立新的连接就会发出信号
    connect(lisSocket,&QTcpServer::newConnection,this,&Widget::acceptConnection);


}

Widget::~Widget()
{
    delete ui;
}

//发送数据给客户端
void Widget::on_pushButton_clicked()
{
    QString senMsg = ui->lineEdit->text(); //获取要发送的字符串
    if(!senMsg.isEmpty())
    {
       QByteArray arr;
       arr.append(senMsg);
       ui->textBrowser->append(senMsg);//在文本框中也显示发送的内容
       connSocket->write(arr);//把消息写道socket缓冲区
       ui->lineEdit->clear();
    }
}

//建立socket连接
void Widget::acceptConnection()
{
   //三次握手已经完成
    connSocket = lisSocket->nextPendingConnection();//建立socket链接  accept操作
    //建立socket连接以后 连接信号与槽，收到对方信号，就进行读

    connect(connSocket,&QTcpSocket::readyRead,this,&Widget::readData);

}

void Widget::readData()
{
    QByteArray recvMsg = connSocket->readAll();//一次性把socket中的内容全部读完
    ui->textBrowser->append(QString(recvMsg));//把字节数组强转字符串

}




